testing online upload of inputs

PlotR version 23.3.3 .
